/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author J3 PC12
 */
public class PruebaEMPLEADO {

   
    public static void main(String[] args) { 
    }
        String  apellidos;
        String  telefono;
        double  horas_Extra;
        double  Horas_trabajadas;

    public PruebaEMPLEADO(String apellidos, String telefono, double horas_Extra, double Horas) {
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.horas_Extra = horas_Extra;
        this.Horas_trabajadas = Horas;
    }
        
   public void mostrarInformacion (){
        System.out.println("apellidos" + apellidos);
        System.out.println("telefono" + telefono);
        System.out.println("horas_Extra" + horas_Extra); 
        System.out.println("Horas_trabajadas" + Horas_trabajadas);
    }
   
}
  