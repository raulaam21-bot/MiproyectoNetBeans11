/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author J3 PC12
 */
public class empleado {
  String  nombre;
  String  cedula;
  double  horas_Trabajadas;
  double  Valor_Horas;

    public empleado(String nombre, String cedula, double horas_Trabajadas, double Valor_Horas) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.horas_Trabajadas = horas_Trabajadas;
        this.Valor_Horas = Valor_Horas;   
   }   
    
        
    public double calcularPago(){
       if(horas_Trabajadas > 80){
           recargo = horas_Trabajadas * 0.25;
           total = recargo/(Valor_Horas);
           System.out.println("total" + total);
           return total;
        }else{
          exedente <= 80;
          Pago = horas_Trabajadas*Valor_Horas; 
          System.out.println("pago" + pago);
          return pago; 
        }
  }
    public String evaluarJornada(){
        if(horas_Trabajadas >= 80){
         System.out.println("Jornada con horas extra");
     }else if(horas_Trabajadas >= 60 && horas_Trabajadas <= 80){
         System.out.println("Jornada completa");
     }         
     else{
         System.out.println("jornada incompleta");
    }   
        
     public void mostrarInformacion(){
     System.out.println("El trabajador "+ nombre +" concedula de ciudadania"+ cedula +"sus horas de trabajo son"+ horas_Trabajadas) ;  
      pago.CalcularPago();
        System.out.println("su sueldo total es de:  $  " + pago.calcularPago());
        System.out.println("");
        evaluacion.evaluarJornada();
        System.out.println("su evaluacionn de jornada es:  $  " + evaluacion.evaluarJornada());
        System.out.println("");
  }
