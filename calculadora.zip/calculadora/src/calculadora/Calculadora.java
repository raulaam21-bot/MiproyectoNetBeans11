/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;


public class Calculadora {

   
    public static void main(String[] args) {
    int operacion =0;
    int numero1 = 4;
    int numero2 = 2;
    int resultado = 0;
     
  if(operacion == 1){
  resultado = numero1 + numero2;
      System.out.println("el resultado de la suma es : " + resultado);
  }
  else if(operacion ==2){
  resultado =numero1-numero2;
   System.out.println("el resultado de la resta es : " + resultado);
  }
  else if(operacion ==3){
    resultado = numero1*numero2;
    System.out.println("el resultado de la multiplicacion es : " + resultado);
    }
  else {
    resultado = numero1/numero2;
    System.out.println("el resultado de la division  es : " + resultado);
    }
  

    }
    
}
