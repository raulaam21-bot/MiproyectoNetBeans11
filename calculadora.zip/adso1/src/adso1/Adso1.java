/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package adso1;

public class Adso1 {

    
    public static void main(String[] args) {
     int  n1 = 69;
     int  n2 = 79;
     int  n3 = 60;
     int  n4 = 80;
     int resultado=0;
     
    resultado =(n1+n2+n3+n4)/4;
     
     if (resultado> 60 ){
         System.out.println("con la nota apruebas Exitosamente" + resultado);
     }
     else {
         System.out.println("Losiento no aprobaste" + resultado);
     }
     
    }
    
}
