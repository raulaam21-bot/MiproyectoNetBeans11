/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package class_libro;

/**
 *
 * @author J3 PC12
 */
public class Class_libro {

   String titulo;
   String autor;
   boolean disponible;

    public Class_libro(String titulo, String autor, boolean disponible) {
        this.titulo = titulo;
        this.autor = autor;
        this.disponible = disponible;
    }
   
  
    public static void main(String[] args) {
        System.out.println("paso 1: Calentando agua a 50°c...");
         System.out.println("paso 2: filtrando agua atravez del cafe molido");
          System.out.println("paso 3: su cafe ya esta listo en la taza");
    }
    
}
