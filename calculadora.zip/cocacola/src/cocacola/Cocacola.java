/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cocacola;
import java.util.Scanner;

public class Cocacola {

    public static void main(String[] args) {
     Scanner entrada = new Scanner(System.in);
     String nombre = "";
     int clave = 0;
     int antiguedad =0;
        System.out.println("*****************************************************");
        System.out.println("*Bienvenido Al Sistema Vacional De Coca-cola Company*");
        System.out.println("*****************************************************");
        System.out.println("");
        System.out.println("");
        
        System.out.println("Digite el Nombre de Empleado");
        nombre= entrada.nextLine();
        System.out.println("Digite la Antiguedad de Empleado");
        antiguedad= entrada.nextInt();
        System.out.println("Digite la Clave de Empleado");
        clave= entrada.nextInt();
        
        if(clave ==1){
            
     if(antiguedad ==1){
         System.out.println("El trabajador "+ nombre +" tiene derecho a 6 dias de vacaciones");
     }else if(antiguedad >= 2 && antiguedad <= 6){
         System.out.println("El trabajador "+ nombre +" tiene derecho a 14 dias de vacaciones");
     }else if(antiguedad >= 7){
         System.out.println("El trabajador "+ nombre +" tiene derecho a 20 dias de vacaciones");
     }else {
         System.out.println("El trabajador aun no tiene derecho a dias de vacaciones");
     }          
        }
        
        
     if(clave ==2){
            
     if(antiguedad ==1){
         System.out.println("El trabajador de logistica "+ nombre +" tiene derecho a 7 dias de vacaciones");
     }else if(antiguedad >= 2 && antiguedad <= 6){
         System.out.println("El trabajador de logistica "+ nombre +" tiene derecho a 15 dias de vacaciones");
     }else if(antiguedad >= 7){
         System.out.println("El trabajador de logistica"+ nombre +" tiene derecho a 22 dias de vacaciones");
     }else {
         System.out.println("El trabajador de logistica aun no tiene derecho a dias de vacaciones");
     }          
        }  
     
    if(clave ==3){
            
     if(antiguedad ==1){
         System.out.println("El trabajador de Gerencia "+ nombre +" tiene derecho a 10 dias de vacaciones");
     }else if(antiguedad >= 2 && antiguedad <= 6){
         System.out.println("El trabajador de Gerencia "+ nombre +" tiene derecho a 20 dias de vacaciones");
     }else if(antiguedad >= 7){
         System.out.println("El trabajador de Gerencia"+ nombre +" tiene derecho a 30 dias de vacaciones");
     }else {
         System.out.println("El trabajador de Gerencia aun no tiene derecho a dias de vacaciones");
     }          
        }   
    else{
        System.out.println("La clave es inexistente vuelve a intentar");
    }
        
    }
    
}
