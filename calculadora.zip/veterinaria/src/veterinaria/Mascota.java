/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package veterinaria;

/**
 *
 * @author J3 PC12
 */
public class Mascota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        animales nombre1 =  new animales();
      
      nombre1.setnombre("roky");
       nombre1.setespecie("perro");
        nombre1.setedad(7); 
        
        
       System.out.println("El nombre de tu mascota es:  " + nombre1.getnombre());
       System.out.println("la especie de tu mascota es:  " + nombre1.getespecie());
       System.out.println("la edad de tu mascota es:  " + nombre1.getedad());
       
        nombre1.setedad(7);
       
    }
    
    
}
