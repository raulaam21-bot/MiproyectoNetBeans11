/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edad;
import java.util.Scanner;

public class Edad {
public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String edad = "";
        int num1=0;
        int num2=0;
        int num3=0;
        int resultado=0;
        
        
        System.out.println("Cual Es Su Nombre");
        edad = entrada.next();
        System.out.println("Cual Es La Primera Nota");
        num1 = entrada.nextInt();
        System.out.println("Cual Es La Segunda Nota");
        num2 = entrada.nextInt();
        System.out.println("Cual Es La Tercera Nota");
        num3 = entrada.nextInt();
        resultado = (num1+num2+num3)/3;
        if(resultado<60 ){
            System.out.println("Hola" + edad + " El resultado de tus notas es : " + resultado + "reprobaste");
        }
        else{
        System.out.println(" Hola "   + edad + " El resultado de tus notas es : " + resultado + " Aprobaste");
        }
        

    }
}

