/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_cafe;

/**
 *
 * @author J3 PC12
 */
public class cafetera {
    String marca;
    String color;

    public cafetera(String marca, String color) {
        this.marca = marca;
        this.color = color;
    }
    
    public void prepararcafe(){
        
        
        
        
        System.out.println("paso 1: Calentando agua a 50°c...");
         System.out.println("paso 2: filtrando agua atravez del cafe molido");
          System.out.println("paso 3: su cafe ya esta listo en la taza");
    }
    
}
