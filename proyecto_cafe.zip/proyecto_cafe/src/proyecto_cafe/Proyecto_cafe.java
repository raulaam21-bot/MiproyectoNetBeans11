/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto_cafe;

/**
 *
 * @author J3 PC12
 */
public class Proyecto_cafe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        cafetera micafetera = new cafetera("oster", "negro");
        
        micafetera.prepararcafe();
    }
    
}
