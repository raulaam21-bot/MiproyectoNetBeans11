/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto_cafe;

/**
 *
 * @author J3 PC12
 */
public class productos {
    String nombre ;
    String codigo ;
    double precio ;

    public productos(String nombre, String codigo, double precio) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
    }
    public void mostrarInformacion (){
        System.out.println("nombre" + nombre);
        System.out.println("codigo" + codigo);
        System.out.println("precio" + precio); 
    }
    
   
}
