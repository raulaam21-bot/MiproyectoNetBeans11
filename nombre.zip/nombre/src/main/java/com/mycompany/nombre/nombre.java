/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.nombre;
import java.util.Scanner;

public class nombre {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String nombre = "";
        int num1=0;
        int num2=0;
        int resultado=0;
        
        
        System.out.println("Cual Es Su Nombre");
        nombre = entrada.next();
        System.out.println("Cual El Primer Valor");
        num1 = entrada.nextInt();
        System.out.println("Cual El Segundo Valor");
        num2 = entrada.nextInt();
        resultado = num1+num2;
        System.out.println("Hola"+ nombre + "El resultado de la suma es: " + resultado);
    }
}
