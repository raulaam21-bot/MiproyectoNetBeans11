/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package candado;

/**
 *
 * @author J3 PC12
 */
public class principal {

    
    public static void main(String[] args) {
      persona persona1 =  new persona();
      
      persona1.setEdad(25);
      
        System.out.println("la edad es:  " + persona1.getEdad());
        
        persona1.setEdad(25);
    }
    
}
