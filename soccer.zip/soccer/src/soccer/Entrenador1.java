/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package soccer;


public class Entrenador1 extends seleccionsoccer{
    String idFederacion;
    
    public Entrenador1(){
        super();
    }

    public Entrenador1(String idFederacion, int Id, String Apellidos, String Nombre, int Edad) {
        super(Id, Apellidos, Nombre, Edad);
        this.idFederacion = idFederacion;
    }
    public String getdemarcacion(){
        return idFederacion;
    }public void set(String idFederacion){
        this.idFederacion = idFederacion;
    }
    public String getidFederacion(){
        return idFederacion;
    }
    public void setidFederacion(String idFederacion){
        this.idFederacion = idFederacion;
    }
    public void dirijirPartido(){};
     public void dirijirEntrenamiento(){};
}
