/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package soccer;

public class futbolista{
    
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private int idorsal;
    
}public class Entrenador{
    
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private String  idferedacion;
    
}public class Masajista{
    
    private int id;
    private String nombre;
    private String apellido;
    private int edad;
    private String titulacion;
    private int añosExperiencia;
    
}
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
