/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author J3 PC12
 */
public class seleccionsoccer {
    protected int Id;
    protected String Apellidos;
    protected String Nombre;
    protected int Edad;

public seleccionsoccer(){
    
}    
    public seleccionsoccer(int Id, String Apellidos, String Nombre, int Edad) {
        this.Id = Id;
        this.Apellidos = Apellidos;
        this.Nombre = Nombre;
        this.Edad = Edad;
    }
  
    public int getid(){
        return Id;
    }public void setid(int Id){
        this.Id = Id;
    }
    
    
    public String getApellidos(){
        return Apellidos;
    }public void setApellidos(String Apellidos){
        this.Apellidos = Apellidos;
    }
    
    
    public String getNombre(){
        return Nombre;
    }public void setNombre(String Nombre){
        this.Nombre = Nombre;
    }
    
    
    public int getEdad(){
        return Edad;
    }public void setEdad(int Edad){
        this.Edad = Edad;
    }
    
    
    
     public void viajar(){
        System.out.println("viajar");
    }
    public void concentrarse(){
        System.out.println("concentrarse");
    }
}



