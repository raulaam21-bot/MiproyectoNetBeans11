/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tienda;

/**
 *
 * @author J3 PC12
 */
public class producto {
    String nombre ;
    String codigo ;
    double precio ;

    public producto(String nombre, String codigo, double precio) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.precio = precio;
    }
     public void mostrarInformacion (){
        System.out.println("nombre:" + nombre);
        System.out.println("codigo:" + codigo);
        System.out.println("precio:" + precio); 
    }
     public double calcularPrecio(){
         return precio - (precio * 0.10);
     }
}
