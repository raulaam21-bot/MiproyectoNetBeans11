/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tienda;

/**
 *
 * @author J3 PC12
 */
public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       producto producto1 = new producto("TECLADO","POOL1", 800000);
       producto producto2 = new producto("MOUSE","POOL2", 600000);
        System.out.println("========PRODUCTO1======");
        
        producto1.mostrarInformacion();
        System.out.println("preio con descuento:  $  " + producto1.calcularPrecio());
        System.out.println("");
        
        System.out.println("========PRODUCTO2======");
        
        producto2.mostrarInformacion();
        System.out.println("preio con descuento:  $  " + producto2.calcularPrecio());
        
    }
    
}
